function goToPage() {
  window.location.href = "html2.html";
}